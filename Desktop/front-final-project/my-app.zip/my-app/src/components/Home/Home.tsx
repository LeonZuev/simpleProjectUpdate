export default function Home(): JSX.Element {
	return <div>Домашняя страница</div>;
}
